﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace OpenTK_console_sample02
{
    class Triangle3D
    {
        private Vector3 pointA;
        private Vector3 pointB;
        private Vector3 pointC;
        int alpha = 255;
        private bool myVisibility;
        private Color myColor;
        int[] rgb = new int[3];
        private Randomizer localR;

        public Triangle3D(Vector3 A, Vector3 B, Vector3 C)
        {
            localR = new Randomizer();
            pointA = A;
            pointB = B;
            pointC = C;
            myColor = localR.RandomColor();
            myVisibility = true;
        }
      
        public Triangle3D(Randomizer _r)
        {
            localR = _r;
            pointA = localR.Random3DPoint();
            pointB = localR.Random3DPoint();
            pointC = localR.Random3DPoint();
            myColor = localR.RandomColor();
            myVisibility = true;
        }


        public static Triangle3D citire_fisier()
        {

            Vector3[] vect;
            string fisier = "C:\\Users\\eliar\\Desktop\\EGC\\Arseni_Adelina_3131B_Lab_EGC\\OpenTK_Introducere\\OpenTK_console_sample02\triunghi.txt";

            using (StreamReader s = new StreamReader(fisier))
            {
                string line;

                while ((line = s.ReadLine()) != null)
                {
                    string[] st = line.Split(' ');
                    vect = new Vector3[st.Length];
                    for (int i = 0; i < st.Length; i++)
                    {
                        string[] pt = st[i].Split(',');
                        Vector3 pnt = new Vector3(Int32.Parse(pt[0]), Int32.Parse(pt[1]), Int32.Parse(pt[2]));
                        vect[i] = pnt;
                    }

                    Triangle3D triunghi = new Triangle3D(vect[0], vect[1], vect[2]);
                    return triunghi;

                }

            }
            return null;
        }
        public void Draw()
        {
            if (myVisibility)
            {
                GL.Begin(PrimitiveType.Triangles);
                GL.Enable(EnableCap.Blend);
                GL.Color4(myColor);
                GL.Vertex3(pointA);
                GL.Vertex3(pointB);
                GL.Vertex3(pointC);
                GL.End();
            }
        }

        public void schimba_culoare(int k)
        {
            if (k < 0)
            {
                alpha -= 2;
            }
            else
            {
                alpha += 2;
            }

            if (alpha <= 0)
            {
                alpha = 0;
            }
            if (alpha >= 255)
            {
                alpha = 255;
            }

            myColor = Color.FromArgb(alpha, rgb[0], rgb[1], rgb[2]);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
            Draw();
            Console.WriteLine(alpha);
        }

        public void Show()
        {
            myVisibility = true;
        }

        public void Hide()
        {
            myVisibility = false;
        }

        public void ToggleVisibility()
        {
            myVisibility = !myVisibility;
        }

        public void DiscoMode()
        {
            myColor = localR.RandomColor();
        }
    }
}
